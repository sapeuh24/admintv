<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AdminTV</title>

    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="<?php echo e(asset('css/styles.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('assets/vendors/simple-datatables/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendors/perfect-scrollbar/perfect-scrollbar.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('assets/vendors/bootstrap-icons/bootstrap-icons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/jquery.dataTables.min.css')); ?>">
    <link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.3.4/css/buttons.dataTables.min.css">

    <link rel="shortcut icon" href="<?php echo e(asset('assets/images/favicon.png')); ?>" type="image/x-icon">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
</head>

<body>
    <div id="app">
        <div id="sidebar" class="active">
            <div class="sidebar-wrapper active">
                <div class="sidebar-header">
                    <div class="d-flex justify-content-center">
                        <a href="<?php echo e(route('/')); ?>"><img src="<?php echo e(asset('assets/images/logo.png')); ?>" alt="Logo"
                                class="img-fluid" style="height: 6.5rem"></a>
                        <div class="toggler">
                            <a href="#" class="sidebar-hide d-xl-none d-block"><i
                                    class="bi bi-x bi-middle"></i></a>
                        </div>
                    </div>
                </div>
                <div class="sidebar-menu">
                    <ul class="menu">
                        <li class="sidebar-item  ">
                            <a href="<?php echo e(route('/')); ?>" class='sidebar-link'>
                                <i class="bi bi-graph-up"></i>
                                <span>Dashboard</span>
                            </a>
                        </li>

                        <?php if(auth()->user()->can('Ver Ver roles y permisos') ||
                                auth()->user()->can('Ver usuarios') ||
                                auth()->user()->can('Ver ventas') ||
                                auth()->user()->can('Ver anulaciones')): ?>
                            <li class="sidebar-title">Administración</li>
                        <?php endif; ?>
                        <?php if(auth()->user()->can('Ver roles y permisos')): ?>
                            <li class="sidebar-item  ">
                                <a href="<?php echo e(route('roles_permisos')); ?>" class='sidebar-link'>
                                    <i class="bi bi-gear-fill"></i>
                                    <span>Roles y permisos</span>
                                </a>
                            </li>
                        <?php endif; ?>

                        <?php if(auth()->user()->can('Ver usuarios')): ?>
                            <li class="sidebar-item">
                                <a href="<?php echo e(route('usuarios')); ?>" class='sidebar-link'>
                                    <i class="bi bi-person-fill"></i>
                                    <span>Usuarios</span>
                                </a>
                            </li>
                        <?php endif; ?>

                        <?php if(auth()->user()->can('Ver empresas')): ?>
                            <li class="sidebar-item">
                                <a href="<?php echo e(route('empresas')); ?>" class='sidebar-link'>
                                    <i class="bi bi-building"></i>
                                    <span>Empresas</span>
                                </a>
                            </li>
                        <?php endif; ?>

                        <?php if(auth()->user()->hasRole('Vendedor')): ?>
                            <li class="sidebar-item">
                                <a href="<?php echo e(route('mis_ventas')); ?>" class='sidebar-link'>
                                    <i class="bi bi-clipboard-data"></i>
                                    <span>Mis ventas</span>
                                </a>
                            </li>
                        <?php endif; ?>

                        <?php if(auth()->user()->can('Ver ventas')): ?>
                            <li class="sidebar-item">
                                <a href="<?php echo e(route('ventas')); ?>" class='sidebar-link'>
                                    <i class="bi bi-clipboard-data"></i>
                                    <span>Ventas</span>
                                </a>
                            </li>
                        <?php endif; ?>

                        <?php if(auth()->user()->can('Ver anulaciones')): ?>
                            <li class="sidebar-item">
                                <a href="<?php echo e(route('anulaciones')); ?>" class='sidebar-link'>
                                    <i class="bi bi-x-circle"></i>
                                    <span>Anulaciones</span>
                                </a>
                            </li>
                        <?php endif; ?>

                        <?php if(auth()->user()->can('Ver tarifas') ||
                                auth()->user()->can('Ver aplicaciones') ||
                                auth()->user()->can('Ver dispositivos') ||
                                auth()->user()->can('Ver pasarelas')): ?>
                            <li class="sidebar-title">Parametrizar</li>
                        <?php endif; ?>

                        <?php if(auth()->user()->can('Ver tarifas')): ?>
                            <li class="sidebar-item">
                                <a href="<?php echo e(route('tarifas')); ?>" class='sidebar-link'>
                                    <i class="bi bi-receipt"></i>
                                    <span>Tarifas</span>
                                </a>
                            </li>
                        <?php endif; ?>

                        <?php if(auth()->user()->can('Ver aplicaciones')): ?>
                            <li class="sidebar-item">
                                <a href="<?php echo e(route('aplicaciones')); ?>" class='sidebar-link'>
                                    <i class="bi bi-app-indicator"></i>
                                    <span>Aplicaciones</span>
                                </a>
                            </li>
                        <?php endif; ?>

                        <?php if(auth()->user()->can('Ver dispositivos')): ?>
                            <li class="sidebar-item">
                                <a href="<?php echo e(route('dispositivos')); ?>" class='sidebar-link'>
                                    <i class="bi bi-display"></i>
                                    <span>Dispositivos</span>
                                </a>
                            </li>
                        <?php endif; ?>

                        <?php if(auth()->user()->can('Ver pasarelas')): ?>
                            <li class="sidebar-item  ">
                                <a href="<?php echo e(route('pasarelas')); ?>" class='sidebar-link'>
                                    <i class="bi bi-cash"></i>
                                    <span>Pasarelas</span>
                                </a>
                            </li>
                        <?php endif; ?>

                        <li class="sidebar-title">Gestión</li>

                        <li class="sidebar-item  ">
                            <a href="<?php echo e(route('clientes')); ?>" class='sidebar-link'>
                                <i class="bi bi-person-lines-fill"></i>
                                <span>Clientes</span>
                            </a>
                        </li>

                        
                        <li class="sidebar-item  ">
                            <a href="<?php echo e(route('logout')); ?>" class='sidebar-link'
                                onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                <i class="bi bi-box-arrow-right"></i>
                                <span>Salir</span>
                            </a>
                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST"
                                style="display: none;">
                                <?php echo e(csrf_field()); ?>

                            </form>
                        </li>
                    </ul>
                </div>
                <button class="sidebar-toggler btn x"><i data-feather="x"></i></button>
            </div>
        </div>
        <header class="mb-3">
            <a href="#" class="burger-btn d-block d-xl-none">
                <i class="bi bi-justify fs-3"></i>
            </a>
        </header>
        <main class="py-4">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"
        integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <script src="<?php echo e(asset('assets/vendors/perfect-scrollbar/perfect-scrollbar.min.js')); ?>"></script>
    <script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendors/simple-datatables/simple-datatables.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.validate.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/chartjs/Chart.min.js')); ?>"></script>
    <?php echo $__env->yieldContent('scripts'); ?>
    <script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>
</body>

</html>
<?php /**PATH C:\wamp64\www\admintv\resources\views/layouts/app.blade.php ENDPATH**/ ?>