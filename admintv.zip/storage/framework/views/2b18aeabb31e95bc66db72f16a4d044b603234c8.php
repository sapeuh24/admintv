
<?php $__env->startSection('content'); ?>
    <div id="main">
        <div class="page-heading">
            <div class="page-title">
                <div class="row">
                    <div class="col-12 col-md-6 order-md-1 order-last">
                        <h3>Anulaciones</h3>
                        <p class="text-subtitle text-muted">Administración de anulaciones de servicio</p>
                    </div>
                    <div class="col-12 col-md-6 order-md-2 order-first">
                        <nav aria-label="breadcrumb" class="breadcrumb-header float-start float-lg-end">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?php echo e(route('/')); ?>">Inicio</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Anulaciones</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
            <section class="section">
                <div class="card">
                    <div class="card-header">
                        Anulaciones
                    </div>

                    <div class="card-body">
                        <div class="row">
                            <div class="container">
                                <?php if($errors->any()): ?>
                                    <div class="alert alert-danger">
                                        <ul>
                                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li class="text-white"><?php echo e($error); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                <?php endif; ?>
                                <?php if(session()->has('success')): ?>
                                    <div class="alert alert-success text-white">
                                        <?php echo e(session()->get('success')); ?>

                                    </div>
                                <?php endif; ?>
                                <?php if(session()->has('error')): ?>
                                    <div class="alert alert-danger text-white">
                                        <?php echo e(session()->get('error')); ?>

                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <table class="table" id="tableanulaciones">
                            <thead>
                                <tr>
                                    <th>Cliente</th>
                                    <th>Tarifa</th>
                                    <th>Usuario</th>
                                    <th>Observaciones</th>
                                </tr>
                            </thead>
                            <tbody>

                            </tbody>
                        </table>
                    </div>
                </div>
            </section>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function() {
            $('#tableanulaciones').DataTable({
                processing: true,
                serverSide: true,
                ajax: "<?php echo e(route('obtener_anulaciones')); ?>",
                columns: [{
                        data: 'cliente.nombre',
                        name: 'cliente.nombre'
                    },
                    {
                        data: 'tarifa.tarifa',
                        name: 'tarifa.tarifa'
                    },
                    {
                        data: 'usuario.name',
                        name: 'usuario.name'
                    },
                    {
                        data: 'observaciones',
                        name: 'observaciones'
                    },
                ],
                "language": {
                    "lengthMenu": "Mostrar _MENU_ registros por página",
                    "zeroRecords": "No se encontraron registros",
                    "info": "Mostrando página _PAGE_ de _PAGES_",
                    "infoEmpty": "No hay registros disponibles",
                    "infoFiltered": "(filtrado de _MAX_ registros totales)",
                    "search": "Buscar:",
                    "paginate": {
                        "first": "Primero",
                        "last": "Último",
                        "next": "Siguiente",
                        "previous": "Anterior"
                    },
                },
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\admintv\resources\views/anulaciones.blade.php ENDPATH**/ ?>