<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AdminTv</title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href=" <?php echo e(asset('assets/css/bootstrap.css')); ?> ">
    <link rel="stylesheet" href=" <?php echo e(asset('assets/vendors/bootstrap-icons/bootstrap-icons.css')); ?> ">
    <link rel="stylesheet" href=" <?php echo e(asset('assets/css/app.css')); ?> ">
    <link rel="stylesheet" href=" <?php echo e(asset('assets/css/pages/auth.css')); ?> ">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
</head>

<body>
    <?php echo $__env->yieldContent('content'); ?>
</body>

</html>
<?php /**PATH C:\wamp64\www\admintv\resources\views/layouts/auth.blade.php ENDPATH**/ ?>